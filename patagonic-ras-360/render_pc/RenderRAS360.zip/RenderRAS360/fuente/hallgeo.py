# Hall geometry taken from the floor plan (image px -> metres via the 26.4 m dimension line).
# x = east, y = north, z = up; origin at the front banner.
import numpy as np, math
PX=26.4/350.0
def m(X,Y): return np.array([(X-761)*PX, -(Y-229)*PX])
# name, plan endpoints (image px), point on the public side, width, height, bottom height, resolution
SCREENS=[
 ('banner_frontal',  (761,190),(761,268), (800,229), 4.0,1.0, 3.0, (1344,366)),
 ('totem_N1',        (845,189),(869,189), (857,229), 1.0,3.0, 0.0, (336,1008)),
 ('totem_N2',        (902,189),(926,189), (914,229), 1.0,3.0, 0.0, (336,1008)),
 ('totem_N3',        (969,189),(993,189), (981,229), 1.0,3.0, 0.0, (336,1008)),
 ('totem_N4',        (1031,189),(1055,189),(1043,229),1.0,3.0, 0.0, (336,1008)),
 ('concava',         (1072,184),(1116,248),(1040,240),6.0,5.0, 0.3, (2016,1680)),
 ('cocina',          (1342,380),(1416,325),(1300,330),4.0,2.0, 1.5, (1344,672)),
 ('totem_R1',        (1207,397),(1243,420),(1205,455),1.0,2.0, 0.0, (336,672)),
 ('totem_R2',        (1222,505),(1245,472),(1205,455),1.0,2.0, 0.0, (336,672)),
 ('banner_lateral',  (782,274),(962,274), (872,240), 8.0,1.0, 3.0, (2688,336)),
]
EYE_H=1.7
def screen(s):
    name,a,b,inside,W,H,z0,res=s
    A,B=m(*a),m(*b); c=(A+B)/2; t=(B-A)/np.linalg.norm(B-A)
    n=np.array([-t[1],t[0]]);
    if np.dot(m(*inside)-c,n)<0: n=-n                       # n points to the public side
    zc=z0+H/2
    D=max(4.0,1.1*max(W,H))                                  # viewer stands D metres in front of the screen
    eye=np.array([c[0]+n[0]*D,c[1]+n[1]*D,EYE_H])
    return dict(name=name,c=np.array([c[0],c[1],zc]),t=np.array([t[0],t[1],0.0]),n=np.array([n[0],n[1],0.0]),W=W,H=H,res=res,eye=eye,D=D)
SC=[screen(s) for s in SCREENS]
# swim circuit: 3.5 m behind each screen (inside the water), in this order, closed loop, smoothed
ORDER=['banner_frontal','totem_N1','totem_N2','totem_N3','totem_N4','concava','banner_lateral']   # cocina and rotunda totems: standalone, own local schools (local_loop)
BEHIND=3.5
SINGLE={'totem_R1','totem_R2'}
LEADIN={}
# waypoints (x,y) after a screen: the hall circuit swings round the back of the building instead of cutting
# through the concave screen's view on its way back to the side banner (the kitchen leg used to do this)
VIA={'concava':[(34.0,-5.0),(26.0,-11.0),(17.0,-10.0)]}   # extra waypoint: (metres before the screen along travel, metres further back)
def clear_views(C,clear=2.4,pad=2.6,iters=80):
    # The route must never run through what a screen shows in front of its glass (the room side): push every
    # path point that lies inside a screen's visible pyramid (widened by `pad` for the school's width) and less
    # than `clear` metres behind the glass out by the shortest exit, then relax the closed curve so it stays smooth.
    C=C.copy(); up=np.array([0,0,1.0])
    for it in range(iters):
        moved=False
        for s in SC:
            c,n,t=s['c'],s['n'],s['t']; e=s['eye']; D=s['D']; rel=C-e; along=rel@(-n); d=along-D
            ox=rel@t-((c-e)@t)*along/D; oz=rel[:,2]-(c[2]-e[2])*along/D
            hx=(s['W']/2)*along/D+pad; hz=(s['H']/2)*along/D+pad
            ins=(along>0.05)&(np.abs(ox)<hx)&(np.abs(oz)<hz)&(d<clear)
            if not ins.any(): continue
            back=clear-d; side=hx-np.abs(ox); vert=(hz-np.abs(oz))*2.5
            k=np.stack([back,side,vert],-1).argmin(-1)
            v=np.where((k==0)[:,None],(back+0.05)[:,None]*(-n),np.where((k==1)[:,None],(side+0.05)[:,None]*np.sign(ox)[:,None]*t,(vert/2.5+0.05)[:,None]*np.sign(oz)[:,None]*up))
            C[ins]+=0.5*v[ins]; moved=True
        for _ in range(3): C=0.5*C+0.25*(np.roll(C,1,0)+np.roll(C,-1,0))
        if not moved and it>8: break
    return C

def resample(C,step=0.2):
    # closed curve -> points every `step` metres
    Q=np.vstack([C,C[:1]]); seg=np.linalg.norm(np.diff(Q,axis=0),axis=1); s=np.concatenate([[0],np.cumsum(seg)]); L=s[-1]
    t=np.arange(0,L,step); return np.stack([np.interp(t,s,Q[:,k]) for k in range(3)],1)
def smooth_loop(C,sigma=2.5,step=0.2):
    # gaussian smoothing along the arc (sigma in metres): no kinks, so fish offset sideways in a school
    # (up to ~2.5 m) never fold back or flip heading on a corner
    C=resample(C,step); n=len(C); k=int(3*sigma/step); g=np.exp(-0.5*(np.arange(-k,k+1)*step/sigma)**2); g/=g.sum()
    out=np.zeros_like(C)
    for j,w in zip(range(-k,k+1),g): out+=w*np.roll(C,j,0)
    return out
def finish(C,clear,pad,sigma):
    for _ in range(3): C=smooth_loop(clear_views(C,clear,pad),sigma)
    return C
def circuit(n=2000, behind=BEHIND, dz=0.0, clear=2.4, pad=2.6):
    by={s['name']:s for s in SC}
    pts=[]; cs=[by[k]['c'] for k in ORDER]
    for i,k in enumerate(ORDER):
        s=by[k]; nx=np.array([*VIA[k][0],0.0]) if k in VIA else cs[(i+1)%len(cs)]; d=nx-cs[i-1]; d[2]=0; t=s['t'] if np.dot(s['t'],d)>=0 else -s['t']   # travel direction along the screen
        h=max(s['W']/2,1.0); z=min(max(s['c'][2],1.2),3.6)
        if k in LEADIN:                                    # come in from the side, not straight at the viewer
            a,b=LEADIN[k]; p=s['c']-s['n']*(behind+b)-t*(h+a); p=p.copy(); p[2]=z+dz; pts.append(p)
        if k in SINGLE:                                    # small screens on a curve: one waypoint, crossed on the diagonal
            p=s['c']-s['n']*behind; p=p.copy(); p[2]=z+dz; pts.append(p); continue
        for u in (-h,h):                                   # two points: the path runs parallel behind every screen
            p=s['c']-s['n']*behind+t*u; p=p.copy(); p[2]=z+dz; pts.append(p)
        for x_,y_ in VIA.get(k,[]):                       # deeper layers swing wider (pushed out from the hall centre)
            o=np.array([x_-14.0,y_-0.0]); o/=np.linalg.norm(o); q=np.array([x_,y_])+o*max(behind-3.5,0)*0.8
            pts.append(np.array([q[0],q[1],z+dz]))
    P=np.array(pts); N=len(P)
    # closed Catmull-Rom
    out=[]
    for i in range(N):
        p0,p1,p2,p3=P[i-1],P[i],P[(i+1)%N],P[(i+2)%N]
        for u in np.linspace(0,1,n//N,endpoint=False):
            out.append(0.5*((2*p1)+(-p0+p2)*u+(2*p0-5*p1+4*p2-p3)*u*u+(-p0+3*p1-3*p2+p3)*u**3))
    C=finish(np.array(out),clear,pad,sigma=min(3.0,1.2+0.12*behind)); seg=np.linalg.norm(np.diff(np.vstack([C,C[:1]]),axis=0),axis=1); L=seg.sum()
    s=np.concatenate([[0],np.cumsum(seg)])
    return C,s,L

def local_loop(names,behind,dz=0.0,n=600,pad=8.0,gap=5.0):
    # Standalone screens: a "stadium" loop behind the screen(s): a straight leg `behind` m back and a return leg
    # `gap` m further back, joined by half-circles. The legs run parallel to the glass and reach `pad` m past the
    # screens on each side, so the fish only ever turn far outside what the screen shows: on screen there are
    # just schools crossing one way (front leg) and the other way (back leg), at two different depths.
    by={s['name']:s for s in SC}; ss=[by[k] for k in names]
    nrm=np.mean([s['n'] for s in ss],0); nrm[2]=0; nrm/=np.linalg.norm(nrm); tan=np.array([-nrm[1],nrm[0],0.0])
    ctr=np.mean([s['c'] for s in ss],0); z=min(max(np.mean([s['c'][2] for s in ss]),1.2),3.6)+dz
    ext=[(s['c']-ctr)@tan+sgn*s['W']/2 for s in ss for sgn in (-1,1)]
    a0,a1=min(ext)-pad,max(ext)+pad; r=gap/2; mid=behind+r
    L1=a1-a0; Lt=2*L1+2*math.pi*r; out=[]
    for u in np.linspace(0,Lt,n,endpoint=False):
        if u<L1: x,yb=a0+u,behind                                            # front leg
        elif u<L1+math.pi*r: th=(u-L1)/r; x,yb=a1+r*math.sin(th),mid-r*math.cos(th)
        elif u<2*L1+math.pi*r: x,yb=a1-(u-L1-math.pi*r),behind+gap         # back leg
        else: th=(u-2*L1-math.pi*r)/r; x,yb=a0-r*math.sin(th),mid+r*math.cos(th)
        p=ctr+tan*x-nrm*yb; p=p.copy(); p[2]=z; out.append(p)
    C=smooth_loop(np.array(out),0.5); seg=np.linalg.norm(np.diff(np.vstack([C,C[:1]]),axis=0),axis=1)   # exact stadium: legs already clear of the glass
    return C,np.concatenate([[0],np.cumsum(seg)]),seg.sum()

def visible_from_any(p,margin=1.0,maxd=60.0):
    # is point p inside any screen's viewing pyramid (widened by `margin` m)?
    for s in SC:
        c,n,t=s['c'],s['n'],s['t']; e=s['eye']; D=s['D']; rel=p-e; along=rel@(-n)
        if along<D or along-D>maxd: continue
        ox=rel@t-((c-e)@t)*along/D; oz=rel[2]-(c[2]-e[2])*along/D
        if abs(ox)<(s['W']/2)*along/D+margin and abs(oz)<(s['H']/2)*along/D+margin: return True
    return False

def straight_lane(names,behind,dz=0.0,margin=1.5):
    # Standalone screens: a straight lane parallel to the glass, long enough that both ends are outside every
    # screen's view. Fish cross it at constant speed and re-enter at the far end (out of sight): no turns at all.
    by={s['name']:s for s in SC}; ss=[by[k] for k in names]
    nrm=np.mean([s['n'] for s in ss],0); nrm[2]=0; nrm/=np.linalg.norm(nrm); tan=np.array([-nrm[1],nrm[0],0.0])
    ctr=np.mean([s['c'] for s in ss],0); z=min(max(np.mean([s['c'][2] for s in ss]),1.2),3.6)+dz
    base=ctr-nrm*behind; base=np.array([base[0],base[1],z])
    def out(a): return not any(visible_from_any(base+tan*a+dv,margin) for dv in (np.zeros(3),-nrm*1.0,nrm*1.0,np.array([0,0,1.0]),np.array([0,0,-1.0])))
    A0=4.0
    while not out(-A0): A0+=0.5
    A1=4.0
    while not out(A1): A1+=0.5
    return base-tan*A0, base+tan*A1
